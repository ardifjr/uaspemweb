<ul id="progressbar">
    <li class="active">
        <div class="multi-step-info">
            <h6>Service Information</h6>
            <p>Lorem ipsum dolor sit</p>
        </div>
        <div class="multi-step-icon">
            <span><i class="fe fe-clipboard"></i></span>
        </div>
    </li>
    <li>
        <div class="multi-step-info">
            <h6>Booking</h6>
            <p>Lorem ipsum dolor sit</p>
        </div>
        <div class="multi-step-icon">
            <span><i class="fe fe-smartphone"></i></span>
        </div>
    </li>
    <li>
        <div class="multi-step-info">
            <h6>Location</h6>
            <p>Lorem ipsum dolor sit</p>
        </div>
        <div class="multi-step-icon">
            <span><i class="fe fe-map-pin"></i></span>
        </div>
    </li>
    <li>
        <div class="multi-step-info">
            <h6>Gallery</h6>
            <p>Lorem ipsum dolor sit</p>
        </div>
        <div class="multi-step-icon">
            <span><i class="fe fe-image"></i></span>
        </div>
    </li>
    <li>
        <div class="multi-step-info">
            <h6>Availability</h6>
            <p>Lorem ipsum dolor sit</p>
        </div>
        <div class="multi-step-icon">
            <span><i class="fe fe-calendar"></i></span>
        </div>
    </li>
</ul>
